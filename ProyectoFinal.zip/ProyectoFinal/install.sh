#!/bin/sh
sudo apt update
sudo apt install docker-compose -y
sudo apt install git
git clone https://github.com/hugo9669/PFinal
sudo uzip ProyectoFinal
cd ProyectoFinal
sudo docker-compose up -d
