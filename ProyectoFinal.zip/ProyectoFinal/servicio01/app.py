import random

class BuscaMinas:
    def __init__(self, filas, columnas, minas):
        self.filas = filas
        self.columnas = columnas
        self.minas = minas
        self.tablero = [['-' for _ in range(columnas)] for _ in range(filas)]
        self.tablero_minas = [[0 for _ in range(columnas)] for _ in range(filas)]
        self.descubiertos = set()
        self.colocar_minas()
        self.calcular_numeros()

    def colocar_minas(self):
        minas_colocadas = 0
        while minas_colocadas < self.minas:
            fila = random.randint(0, self.filas - 1)
            columna = random.randint(0, self.columnas - 1)
            if self.tablero_minas[fila][columna] == 0:
                self.tablero_minas[fila][columna] = -1
                minas_colocadas += 1

    def calcular_numeros(self):
        for fila in range(self.filas):
            for columna in range(self.columnas):
                if self.tablero_minas[fila][columna] == -1:
                    continue
                self.tablero_minas[fila][columna] = sum(
                    self.es_mina(fila + df, columna + dc)
                    for df in [-1, 0, 1]
                    for dc in [-1, 0, 1]
                )

    def es_mina(self, fila, columna):
        return (
            0 <= fila < self.filas
            and 0 <= columna < self.columnas
            and self.tablero_minas[fila][columna] == -1
        )

    def mostrar_tablero(self):
        for fila in self.tablero:
            print(" ".join(fila))

    def descubrir(self, fila, columna):
        if (fila, columna) in self.descubiertos:
            return
        if self.tablero_minas[fila][columna] == -1:
            print("¡BOOM! Has encontrado una mina. ¡Juego terminado!")
            self.mostrar_minas()
            exit()
        self.descubiertos.add((fila, columna))
        self.tablero[fila][columna] = str(self.tablero_minas[fila][columna])
        if self.tablero_minas[fila][columna] == 0:
            for df in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    nf, nc = fila + df, columna + dc
                    if 0 <= nf < self.filas and 0 <= nc < self.columnas:
                        self.descubrir(nf, nc)

    def mostrar_minas(self):
        for fila in range(self.filas):
            for columna in range(self.columnas):
                if self.tablero_minas[fila][columna] == -1:
                    self.tablero[fila][columna] = "*"
        self.mostrar_tablero()

    def juego_ganado(self):
        return len(self.descubiertos) == self.filas * self.columnas - self.minas

def jugar():
    filas = 8
    columnas = 8
    minas = 10
    juego = BuscaMinas(filas, columnas, minas)
    print("¡Bienvenido a Busca Minas!")
    while True:
        juego.mostrar_tablero()
        try:
            fila = int(input("Ingresa la fila (0-{}): ".format(filas - 1)))
            columna = int(input("Ingresa la columna (0-{}): ".format(columnas - 1)))
            if not (0 <= fila < filas and 0 <= columna < columnas):
                print("Coordenadas fuera de rango. Intenta de nuevo.")
                continue
            juego.descubrir(fila, columna)
            if juego.juego_ganado():
                print("¡Felicidades! Has descubierto todas las celdas sin minas.")
                juego.mostrar_tablero()
                break
        except ValueError:
            print("Entrada inválida. Ingresa números válidos.")
